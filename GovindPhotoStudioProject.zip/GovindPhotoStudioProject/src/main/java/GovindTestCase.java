
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

public class GovindTestCase extends JFrame implements ActionListener, DropTargetListener {
	private static final long serialVersionUID = 1L;
	private JList listt = new JList();
	Map<String, String> folderMap = new HashMap<String, String>();
	Map<String, String> intitalDir = new HashMap<String, String>();
	Map<String, HashMap<String, String>> choices = new HashMap<String, HashMap<String, String>>();

	static String textFieldDirectory = "";
	static String subFolderFile1 = "";
	static String subFolderFile2 = "";
	static String sourcePath = "";
	String[] thisIsAStringArray;

	JFileChooser chooser;
	String choosertitle;

	JTextField userInput;
	DropTarget dt;

	JTextArea ta = new JTextArea(30, 100);
	String[] folder1;

	class MyItemListener implements ItemListener {
		// This method is called only if a new item has been selected.
		public void itemStateChanged(ItemEvent evt) {
			JComboBox cb = (JComboBox) evt.getSource();
			Object item = evt.getItem();
			if (evt.getStateChange() == ItemEvent.SELECTED) {
				// System.out.println(item.toString());
				subFolderFile1 = item.toString();
				HashMap<String, String> val = choices.get(item.toString());
				List<String> list = new ArrayList<String>();
				for (Map.Entry<String, String> entry : val.entrySet()) {
					String key = entry.getKey();
					String value = entry.getValue();
					list.add(value);
					// do stuff
				}
				thisIsAStringArray = new String[list.size()];
				int count = 0;
				for (String s : list) {
					thisIsAStringArray[count++] = s;
				}
				// Item was just selected
			} else if (evt.getStateChange() == ItemEvent.DESELECTED) {
				// Item is no longer selected
				// System.out.println("Not Selected" + item.toString());
			}
		}
	}

	class MySubItemListener implements ItemListener {
		// This method is called only if a new item has been selected.
		public void itemStateChanged(ItemEvent evt) {
			JComboBox cb = (JComboBox) evt.getSource();

			Object item = evt.getItem();

			if (evt.getStateChange() == ItemEvent.SELECTED) {
				// System.out.println(item.toString());
				subFolderFile2 = item.toString();
				// Item was just selected
			} else if (evt.getStateChange() == ItemEvent.DESELECTED) {
				// Item is no longer selected
				// System.out.println("Not Selected" + item.toString());
			}
		}
	}

	private void readDirectoryIntital() {
		Properties prop = new Properties();
		InputStream input = null;
		try {

			prop.load(GovindTestCase.class.getResourceAsStream("/main.properties"));
			Enumeration<?> e = prop.propertyNames();
			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				String value = prop.getProperty(key);
				intitalDir.put(key, value);
			}
			if (intitalDir.entrySet().size() > 0) {
				for (Map.Entry m : intitalDir.entrySet()) {
					System.out.println(m.getKey() + " " + m.getValue());
					textFieldDirectory = "" + (String) m.getValue();
				}
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	private void readAllChoices() {

		Properties prop = new Properties();
		InputStream input = null;
		try {

			// String filename = "config.properties";
			prop.load(GovindTestCase.class.getResourceAsStream("/folder.properties"));
			/*
			 * input = getClass().getClassLoader().getResourceAsStream(filename); if (input
			 * == null) { System.out.println("Sorry, unable to find " + filename); return; }
			 */
			// prop.load(input);

			Enumeration<?> e = prop.propertyNames();
			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				String value = prop.getProperty(key);
				folderMap.put(key, value);
				// System.out.println("Key : " + key + ", Value : " + value);
			}
			for (Map.Entry m : folderMap.entrySet()) {
				// System.out.println(m.getKey() + " " + m.getValue());
				List<String> lists = Arrays.asList(m.getValue().toString().split(","));
				// System.out.println(lists);

				Map<String, String> map = new HashMap<String, String>();
				for (int i = 0; i < lists.size(); i++) {
					map.put(i + "", "" + lists.get(i));
				}
				choices.put(m.getKey().toString(), (HashMap<String, String>) map);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	private void submitAction() throws IOException {
		Properties props = new Properties();
		textFieldDirectory = userInput.getText();
		System.out.println(textFieldDirectory);// do whatever you want with the variable, I just printed it to the
		FileOutputStream out = new FileOutputStream("src/main/resources/main.properties");
		props.setProperty("folder", textFieldDirectory);
		props.store(out, null);
		out.close(); // console
	}

	private static void selectDirectory() throws IOException {
		// TODO Auto-generated method stub
		Properties props = new Properties();
		JFileChooser fileopen = new JFileChooser();
		FileFilter filter = new FileNameExtensionFilter("c files", "c");
		fileopen.addChoosableFileFilter(filter);
		fileopen.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

		int ret = fileopen.showDialog(null, "Open file");

		if (ret == JFileChooser.APPROVE_OPTION) {
			File file = fileopen.getSelectedFile();
			textFieldDirectory = file.getAbsolutePath();
			System.out.println(textFieldDirectory);
			FileOutputStream out = new FileOutputStream("src/main/resources/main.properties");
			props.setProperty("folder", textFieldDirectory);
			props.store(out, null);
			out.close();
		}
	}

	private void copyAction() throws IOException {
		// TODO Auto-generated method stub
		String finalPath = textFieldDirectory + "\\" + subFolderFile1 + "\\" + subFolderFile2 + "\\";
		System.out.println(finalPath);
		System.out.println(sourcePath);
		final Path path = Paths.get(finalPath);

		if (Files.notExists(path)) {
			Files.createFile(Files.createDirectories(path)).toFile();
		}
		File dir = new File(finalPath);
		if (!dir.exists())
			dir.mkdirs();
		
		File a = new File(sourcePath);
		a.renameTo(new File(finalPath + a.getName()));
		a.delete();
		// listFiles("C:\\Users\\HDMI\\Downloads\\");
		// tc.moveFileToDirectory("","");
		// listFilesForFolder(folder);

	}

	private void showGui() {
		// create the jframe
		FileDragDemo mainPanel = new FileDragDemo();
		JFrame jFrame = new JFrame();
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.setSize(800, 400);
		jFrame.getContentPane().setBackground(Color.WHITE);
		Container c = jFrame.getContentPane();
		c.setBackground(Color.WHITE);
		// create the left panel
		JPanel menu = new JPanel();
		menu.setBackground(Color.MAGENTA);
		JLabel menulabel = new JLabel("---------------------Govind's PhotoCopy Application--------------");
		menu.add(menulabel);
		JPanel top = new JPanel();
		top.setBackground(Color.yellow);

		JLabel label = new JLabel("Enter Text");
		userInput = new JTextField(textFieldDirectory, 20); // accepts upto 10 characters
		JButton jButton = new JButton("Change");
		jButton.addActionListener((e) -> {
			try {
				submitAction();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});

		top.add(label); // Components Added using Flow Layout
		top.add(userInput);
		top.add(jButton);

		// create the right panel
		JPanel middle = new JPanel();
		middle.setBackground(Color.orange);
		// create the bottom panel
		JPanel green = new JPanel();
		green.setBackground(Color.green);
		String data1 = "";

		JPanel end = new JPanel();
		end.setBackground(Color.CYAN);
		folder1 = choices.keySet().toArray(new String[choices.size()]);

		JComboBox cmiddleb = new JComboBox(folder1);
		cmiddleb.setBounds(50, 100, 90, 20);
		middle.add(cmiddleb);
		cmiddleb.setSelectedItem(null);

		JComboBox<String> cendb = new JComboBox<>(new DefaultComboBoxModel<>());
		cendb.setBounds(50, 100, 90, 20);
		end.add(cendb);
		cendb.setSelectedItem(null);

		cmiddleb.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String value = (String) cmiddleb.getSelectedItem();
				// List<String> secondValues = ;
				HashMap<String, String> val = choices.get(value);
				List<String> list = new ArrayList<String>();
				for (Map.Entry<String, String> entry : val.entrySet()) {
					String key = entry.getKey();
					String values = entry.getValue();
					list.add(values);
					// do stuff
				}
				thisIsAStringArray = new String[list.size()];
				int count = 0;
				for (String s : list) {
					thisIsAStringArray[count++] = s;
				}

				DefaultComboBoxModel model = (DefaultComboBoxModel) cendb.getModel();
				model.removeAllElements();
				for (String s : list) {
					model.addElement(s);
				}
				// System.out.println("Here");
			}
		});

		MyItemListener actionListener = new MyItemListener();
		cmiddleb.addItemListener(actionListener);

		MySubItemListener subListener = new MySubItemListener();
		cendb.addItemListener(subListener);
		JButton jButtonCopy = new JButton("Cut");
		jButtonCopy.addActionListener((e) -> {
			try {
				copyAction();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});

		green.add(jButtonCopy);
		// create the split panes
		ResizableSplitPane topSplit = new ResizableSplitPane(JSplitPane.VERTICAL_SPLIT, menu, top, jFrame);
		ResizableSplitPane horizontalSplitright = new ResizableSplitPane(JSplitPane.VERTICAL_SPLIT, topSplit, middle,
				jFrame);
		ResizableSplitPane horizontalSplit = new ResizableSplitPane(JSplitPane.VERTICAL_SPLIT, horizontalSplitright,
				end, jFrame);

		JPanel green2 = new JPanel();
		final String text = "";
		String[] listString = { "" };
		green2.setBackground(Color.pink);
		JLabel lc = new JLabel("Drop a list from your file chooser here:");
		green2.add(lc);
		green2.add(mainPanel);
		/*
		 * ta.setBackground(Color.white); jFrame.getContentPane().add(ta,
		 * BorderLayout.CENTER); green2.add(ta); dt = new DropTarget(green2, this);
		 */// green2.setDropTarget(new DropTarget() {
		/*			*//**
						* 
						*//*
							 * // List<String> lis= new ArrayList<String>();
							 * 
							 * @SuppressWarnings("unchecked") public synchronized void
							 * drop(DropTargetDropEvent evt) { try {
							 * evt.acceptDrop(DnDConstants.ACTION_COPY); List droppedFiles = (List)
							 * evt.getTransferable().getTransferData(DataFlavor.javaFileListFlavor); if
							 * (droppedFiles.size() > 1) { JOptionPane.showMessageDialog(green2,
							 * "Sorry...can't handle more than one files together."); } else { File
							 * droppedFile = (File) droppedFiles.get(0); //
							 * lis.add(droppedFile.getAbsolutePath()); listString[0] =
							 * droppedFile.getAbsolutePath(); } } catch (Exception ex) {
							 * ex.printStackTrace(); } } });
							 */
		// sourcePath = listString[0];

		ResizableSplitPane verticalSplit = new ResizableSplitPane(JSplitPane.HORIZONTAL_SPLIT, horizontalSplit, green2,
				jFrame);

		ResizableSplitPane verticalSplit2 = new ResizableSplitPane(JSplitPane.VERTICAL_SPLIT, verticalSplit, green,
				jFrame);
		jFrame.getContentPane().add(verticalSplit2);
		// show the gui
		jFrame.setVisible(true);
	}

	/*
	 * public boolean moveFile(String sourcePath, String targetPath) {
	 * 
	 * boolean flag = true;
	 * 
	 * try {
	 * 
	 * Files.move(Paths.get(sourcePath), Paths.get(targetPath),
	 * StandardCopyOption.REPLACE_EXISTING); // Files.move(Paths.get("/foo.txt"),
	 * Paths.get("bar.txt"), // StandardCopyOption.REPLACE_EXISTING); } catch
	 * (Exception e) { flag = false; e.printStackTrace(); }
	 * 
	 * return flag; }
	 * 
	 */ public Dimension getPreferredSize() {
		return new Dimension(200, 200);
	}

	public void actionPerformed(ActionEvent e) {
		chooser = new JFileChooser();
		chooser.setCurrentDirectory(new File("C:\\"));
		chooser.setDialogTitle(choosertitle);
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		//
		// disable the "All files" option.
		//
		chooser.setAcceptAllFileFilterUsed(false);
		//
		if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			System.out.println("getCurrentDirectory(): " + chooser.getCurrentDirectory());
			System.out.println("getSelectedFile() : " + chooser.getSelectedFile());
		} else {
			System.out.println("No Selection ");
		}
	}

	public void dragEnter(DropTargetDragEvent dtde) {
		// System.out.println("Drag Enter");
	}

	public void dragExit(DropTargetEvent dte) {
		// System.out.println("Drag Exit");
	}

	public void dragOver(DropTargetDragEvent dtde) {
		// System.out.println("Drag Over");
	}

	public void dropActionChanged(DropTargetDragEvent dtde) {
		// System.out.println("Drop Action Changed");
	}

	public void drop(DropTargetDropEvent dtde) {
		try {
			// Ok, get the dropped object and try to figure out what it is
			Transferable tr = dtde.getTransferable();
			DataFlavor[] flavors = tr.getTransferDataFlavors();
			for (int i = 0; i < flavors.length; i++) {
				System.out.println("Possible flavor: " + flavors[i].getMimeType());
				// Check for file lists specifically
				if (flavors[i].isFlavorJavaFileListType()) {
					// Great! Accept copy drops...
					dtde.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
					ta.setText("Successful file list drop.\n\n");

					// And add the list of file names to our text area
					java.util.List list = (java.util.List) tr.getTransferData(flavors[i]);
					for (int j = 0; j < list.size(); j++) {
						ta.append(list.get(j) + "\n");
					}

					// If we made it this far, everything worked.
					dtde.dropComplete(true);
					return;
				}
				// Ok, is it another Java object?
				else if (flavors[i].isFlavorSerializedObjectType()) {
					dtde.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
					ta.setText("Successful text drop.\n\n");
					Object o = tr.getTransferData(flavors[i]);
					ta.append("Object: " + o);
					dtde.dropComplete(true);
					return;
				}
				// How about an input stream?
				else if (flavors[i].isRepresentationClassInputStream()) {
					dtde.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
					ta.setText("Successful text drop.\n\n");
					ta.read(new InputStreamReader((InputStream) tr.getTransferData(flavors[i])),
							"from system clipboard");
					dtde.dropComplete(true);
					return;
				}
			}
			// Hmm, the user must not have dropped a file list
			System.out.println("Drop failed: " + dtde);
			dtde.rejectDrop();
		} catch (Exception e) {
			e.printStackTrace();
			dtde.rejectDrop();
		}
	}

	public class ResizableSplitPane extends JSplitPane {

		//
		// instance variables
		//

		private boolean painted;

		private double defaultDividerLocation;

		private double dividerProportionalLocation;

		private int currentDividerLocation;

		private Component first;

		private Component second;

		private boolean dividerPositionCaptured = false;

		//
		// constructors
		//

		public ResizableSplitPane(int splitType, Component first, Component second, Component parent) {
			this(splitType, first, second, parent, 0.5);
		}

		public ResizableSplitPane(int splitType, Component first, Component second, Component parent,
				double defaultDividerLocation) {
			super(splitType, first, second);
			this.defaultDividerLocation = defaultDividerLocation;
			this.dividerProportionalLocation = defaultDividerLocation;
			this.setResizeWeight(defaultDividerLocation);
			this.first = first;
			this.second = second;
			parent.addComponentListener(new DividerLocator());
			second.addComponentListener(new DividerMovedByUserComponentAdapter());
		}

		//
		// trivial getters and setters
		//

		public double getDefaultDividerLocation() {
			return defaultDividerLocation;
		}

		public void setDefaultDividerLocation(double defaultDividerLocation) {
			this.defaultDividerLocation = defaultDividerLocation;
		}

		//
		// implementation
		//

		@Override
		public void paint(Graphics g) {
			super.paint(g);
			if (painted == false) {
				painted = true;
				this.setDividerLocation(dividerProportionalLocation);
				this.currentDividerLocation = this.getDividerLocation();
			}
		}

		private class DividerLocator extends ComponentAdapter {
			@Override
			public void componentResized(ComponentEvent e) {
				setDividerLocation(dividerProportionalLocation);
				currentDividerLocation = getDividerLocation();
			}
		}

		private class DividerMovedByUserComponentAdapter extends ComponentAdapter {
			@Override
			public void componentResized(ComponentEvent e) {
				// System.out.println("RESIZED: " + dividerPositionCaptured);
				int newDividerLocation = getDividerLocation();
				boolean dividerWasMovedByUser = newDividerLocation != currentDividerLocation;
				// System.out.println(
				// currentDividerLocation + "\t" + newDividerLocation + "\t" +
				// dividerProportionalLocation);
				if (dividerPositionCaptured == false || dividerWasMovedByUser == true) {
					dividerPositionCaptured = true;
					painted = false;
					if (getOrientation() == JSplitPane.HORIZONTAL_SPLIT) {
						dividerProportionalLocation = (double) first.getWidth()
								/ (double) (first.getWidth() + second.getWidth());
					} else {
						dividerProportionalLocation = (double) first.getHeight()
								/ (double) (first.getHeight() + second.getHeight());

					}
					// System.out.println(dividerProportionalLocation);
				}
			}
		}

	}

	public static void main(String[] args) throws IOException {
		GovindTestCase tc = new GovindTestCase();
		tc.readDirectoryIntital();
		tc.readAllChoices();
		if (textFieldDirectory.trim().isEmpty() || (textFieldDirectory.trim().length() == 0)) {
			selectDirectory();
		}
		tc.showGui();
	}

}